-- AlterTable
ALTER TABLE "UserTopicProgress" ALTER COLUMN "completed" DROP DEFAULT;
