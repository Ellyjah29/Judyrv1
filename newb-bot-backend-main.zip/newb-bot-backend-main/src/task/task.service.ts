import {
  Injectable,
  NotFoundException,
  ConflictException,
  BadRequestException,
} from '@nestjs/common';
import { CreateTaskDto } from './dto/create-task.dto';
import { PrismaService } from '@app/core/database/prisma.service';
import { toJSON } from '@app/core/utils/functions';
import { fromZonedTime, toZonedTime } from 'date-fns-tz';
import { startOfDay, subDays } from 'date-fns';

interface DefaultTask {
  taskId: string;
  title: string;
  points: number;
  type: 'daily' | 'one-time' | 'social';
  category: 'Daily' | 'Weekly' | 'Social' | 'Academy' | 'Frens' | 'Featured';
  redirectUrl?: string;
  image?: string;
}

@Injectable()
export class TaskService {
  constructor(private prisma: PrismaService) {}

  private readonly defaultTasks: DefaultTask[] = [
    {
      taskId: 'daily-login',
      title: 'Login daily for 100 points',
      points: 100,
      type: 'daily',
      category: 'Daily',
      image: 'images/task-bot.svg',
    },
    {
      taskId: 'join-community',
      title: 'Join Community',
      points: 150,
      type: 'one-time',
      category: 'Social',
      redirectUrl: 'https://t.me/NewbnetSquad',
      image: 'images/task-bot.svg',
    },
    {
      taskId: 'join-channel',
      title: 'Join Channel',
      points: 150,
      type: 'one-time',
      category: 'Social',
      redirectUrl: 'https://t.me/NewbnetUpdates',
      image: 'images/task-bot.svg',
    },
    {
      taskId: 'like-retweet',
      title: 'Like and retweet the post',
      points: 100,
      type: 'social',
      category: 'Social',
      redirectUrl: 'https://x.com/newbnet_/status/1924772583016407398?s=46',
      image: 'images/task-x.svg',
    },
    {
      taskId: 'follow-x',
      title: 'Follow NewbNet X account',
      points: 150,
      type: 'one-time',
      category: 'Social',
      redirectUrl: 'https://x.com/newbnet_?s=21',
      image: 'images/task-x.svg',
    },
    {
      taskId: 'invite-1-fren',
      title: 'Invite 1 friend',
      points: 100,
      type: 'one-time',
      category: 'Frens',
      image: 'images/friends.svg',
    },
    {
      taskId: 'invite-10-frens',
      title: 'Invite 10 friends',
      points: 1500,
      type: 'one-time',
      category: 'Frens',
      image: 'images/friends.svg',
    },
    {
      taskId: 'invite-50-frens',
      title: 'Invite 50 friends',
      points: 10000,
      type: 'one-time',
      category: 'Frens',
      image: 'images/friends.svg',
    },
    {
      taskId: 'invite-100-frens',
      title: 'Invite 100 friends',
      points: 25000,
      type: 'one-time',
      category: 'Frens',
      image: 'images/friends.svg',
    },
    {
      taskId: 'invite-500-frens',
      title: 'Invite 500 friends',
      points: 150000,
      type: 'one-time',
      category: 'Frens',
      image: 'images/friends.svg',
    },
    {
      taskId: 'invite-1000-frens',
      title: 'Invite 1000 friends',
      points: 400000,
      type: 'one-time',
      category: 'Frens',
      image: 'images/friends.svg',
    },
    {
      taskId: 'invite-5000-frens',
      title: 'Invite 5000 friends',
      points: 2500000,
      type: 'one-time',
      category: 'Frens',
      image: 'images/friends.svg',
    },
    {
      taskId: 'invite-10000-frens',
      title: 'Invite 10000 friends',
      points: 6000000,
      type: 'one-time',
      category: 'Frens',
      image: 'images/friends.svg',
    },
    {
      taskId: 'invite-15000-frens',
      title: 'Invite 15000 friends',
      points: 10000000,
      type: 'one-time',
      category: 'Frens',
      image: 'images/friends.svg',
    },
  ];

  async getUserTasks(userId: number) {
    const completedTasks = await this.prisma.task.findMany({
      where: { userId },
      orderBy: { completedAt: 'desc' },
    });

    const nowUtc = new Date();
    const nowInNigeria = toZonedTime(nowUtc, this.nigeriaTimeZone);
    const startOfTodayInNigeriaZone = startOfDay(nowInNigeria);
    const startOfTodayWAT_UTC = fromZonedTime(
      startOfTodayInNigeriaZone,
      this.nigeriaTimeZone,
    );

    return this.defaultTasks.map((task) => {
      const completedRecord = completedTasks.find(
        (t) => t.taskId === task.taskId,
      );

      let isCompleted = false;
      if (completedRecord) {
        if (task.type === 'daily') {
          isCompleted =
            completedRecord.completedAt !== null &&
            completedRecord.completedAt >= startOfTodayWAT_UTC;
        } else {
          isCompleted = true;
        }
      }

      return toJSON({
        ...task,
        completed: isCompleted,
        completedAt: completedRecord?.completedAt,
      });
    });
  }

  async completeTask(userId: number, dto: CreateTaskDto) {
    const { taskId } = dto;

    const taskConfig = this.defaultTasks.find((t) => t.taskId === taskId);
    if (!taskConfig) {
      throw new NotFoundException('Task configuration not found');
    }

    const taskType = taskConfig.type;

    if (taskId === 'daily-login') {
      return this.handleDailyLoginTask(userId, taskConfig);
    }

    // // Find task configuration from defaults
    // const taskConfig = this.defaultTasks.find((t) => t.taskId === taskId);
    // if (!taskConfig) {
    //   throw new NotFoundException('Task configuration not found');
    // }

    // const taskType = taskConfig.type; // Get type from config

    if (taskType === 'daily') {
      const startOfDay = new Date();
      startOfDay.setUTCHours(0, 0, 0, 0);

      const existingToday = await this.prisma.task.findFirst({
        where: {
          userId,
          taskId,
          completedAt: { gte: startOfDay },
        },
      });

      if (existingToday) {
        throw new ConflictException('Daily task already completed today');
      }
    } else if (taskType === 'one-time' || taskType === 'social') {
      const existing = await this.prisma.task.findFirst({
        where: { userId, taskId },
      });

      if (existing) {
        throw new ConflictException(`Task '${taskId}' already completed`);
      }
    } else {
      throw new BadRequestException(`Unsupported task type: ${taskType}`);
    }

    try {
      const [_, completedTask] = await this.prisma.$transaction([
        this.prisma.generalUser.update({
          where: { accountId: userId },
          data: {
            points: { increment: taskConfig.points },
          },
        }),
        this.prisma.task.create({
          data: {
            userId,
            taskId,
            taskType: taskType,
            completed: true,
            completedAt: new Date(),
            // expiresAt might not be strictly needed if checking completedAt >= startOfDay
            // expiresAt: taskType === 'daily' ? /* Calculate next midnight UTC */ : null,
          },
        }),
      ]);

      return {
        message: 'Task completed successfully',
        taskId: completedTask.taskId,
        pointsAwarded: taskConfig.points,
        completedAt: completedTask.completedAt,
      };
    } catch (error) {
      console.error('Error completing task:', error);

      if (
        error instanceof ConflictException ||
        error instanceof NotFoundException ||
        error instanceof BadRequestException
      ) {
        throw error;
      }
      throw new Error('Failed to complete task and update points.');
    }
  }

  private readonly nigeriaTimeZone = 'Africa/Lagos';

  private async handleDailyLoginTask(userId: number, taskConfig: DefaultTask) {
    const nowUtc = new Date();

    const nowInNigeria = toZonedTime(nowUtc, this.nigeriaTimeZone);

    const startOfTodayInNigeriaZone = startOfDay(nowInNigeria);
    const startOfTodayWAT_UTC = fromZonedTime(
      startOfTodayInNigeriaZone,
      this.nigeriaTimeZone,
    );

    const startOfYesterdayWAT_UTC = subDays(startOfTodayWAT_UTC, 1);

    const existingToday = await this.prisma.task.findFirst({
      where: {
        userId,
        taskId: 'daily-login',
        completedAt: { gte: startOfTodayWAT_UTC },
      },
    });

    if (existingToday) {
      throw new ConflictException('Daily login already completed today');
    }

    const streakInfo = await this.prisma.streakInfo.findUnique({
      where: { userId },
    });

    let newStreak = 1;

    if (streakInfo && streakInfo.lastLoginDate) {
      const lastLoginWasYesterdayInWAT =
        streakInfo.lastLoginDate >= startOfYesterdayWAT_UTC &&
        streakInfo.lastLoginDate < startOfTodayWAT_UTC;

      if (lastLoginWasYesterdayInWAT) {
        newStreak = streakInfo.currentStreak + 1;
      } else {
        newStreak = 1;
      }
    } else {
      newStreak = 1;
    }

    try {
      const [_, completedTask, updatedStreakInfo] =
        await this.prisma.$transaction([
          this.prisma.generalUser.update({
            where: { accountId: userId },
            data: {
              points: { increment: taskConfig.points },
            },
          }),
          this.prisma.task.create({
            data: {
              userId,
              taskId: 'daily-login',
              taskType: 'daily',
              completed: true,
              completedAt: nowUtc,
            },
          }),
          this.prisma.streakInfo.upsert({
            where: { userId },
            create: {
              userId,
              currentStreak: newStreak,
              lastLoginDate: nowUtc,
              longestStreak: newStreak,
            },
            update: {
              currentStreak: newStreak,
              lastLoginDate: nowUtc,
              longestStreak: streakInfo
                ? Math.max(streakInfo.longestStreak, newStreak)
                : newStreak,
            },
          }),
        ]);

      return {
        message: 'Daily login task completed successfully',
        taskId: completedTask.taskId,
        pointsAwarded: taskConfig.points,
        completedAt: completedTask.completedAt,
        currentStreak: updatedStreakInfo.currentStreak,
      };
    } catch (error) {
      console.error('Error completing daily login task:', error);
      if (
        error instanceof ConflictException ||
        error instanceof NotFoundException
      ) {
        throw error;
      }
      throw new Error('Failed to complete daily login task.');
    }
  }

  async getStreakInfo(userId: number) {
    return this.prisma.streakInfo.findUnique({
      where: { userId },
      select: {
        currentStreak: true,
        longestStreak: true,
        lastLoginDate: true,
      },
    });
  }
}
