import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { LeaderboardService } from './leaderboard.service';
import { CurrentUserData } from '@app/auth/interfaces';
import { CurrentUser } from '@app/auth/decorators';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiQuery,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';

@ApiTags('Leaderboard')
@ApiBearerAuth()
@Controller('leaderboard')
export class LeaderboardController {
  constructor(private readonly leaderboardService: LeaderboardService) {}

  @Get()
  @ApiOperation({ summary: 'Get leaderboard with pagination' })
  @ApiQuery({
    name: 'page',
    required: false,
    type: Number,
    description: 'Page number (default: 1)',
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    type: Number,
    description: 'Items per page (default: 10)',
  })
  @ApiResponse({
    status: 200,
    description: 'Leaderboard data with pagination info',
  })
  async getLeaderboard(
    @CurrentUser() user: CurrentUserData,
    @Query('page') page: number = 1,
    @Query('limit') limit: number = 10,
  ) {
    page = Math.max(1, Number(page) || 1);
    limit = Math.min(Math.max(1, Number(limit) || 10), 100);

    const response = await this.leaderboardService.getLeaderboard(
      user.accounts[0].id,
      page,
      limit,
    );

    return response;
  }
}
