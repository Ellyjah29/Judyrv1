export class Leaderboard {}
