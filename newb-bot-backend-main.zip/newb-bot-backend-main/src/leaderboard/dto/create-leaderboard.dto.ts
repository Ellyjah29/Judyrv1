export class CreateLeaderboardDto {}
