import { Inject, Injectable } from '@nestjs/common';
import { PrismaService } from '@app/core/database/prisma.service';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import { Cache } from 'cache-manager';
import { toJSON } from '@app/core/utils/functions';

@Injectable()
export class LeaderboardService {
  constructor(
    private readonly prisma: PrismaService,
    @Inject(CACHE_MANAGER) private cacheManager: Cache,
  ) {}

  async getLeaderboard(
    currentUserId?: number,
    page: number = 1,
    limit: number = 10,
  ) {
    const cacheKey = `leaderboard:page:${page}:limit:${limit}`;

    try {
      const cached = await this.cacheManager.get(cacheKey);
      if (cached) {
        return this.processCachedLeaderboard(cached, currentUserId);
      }

      const skip = (page - 1) * limit;
      const take = limit;

      const totalUsers = await this.prisma.generalUser.count();

      const users = await this.prisma.generalUser.findMany({
        select: {
          accountId: true,
          firstName: true,
          lastName: true,
          username: true,
          points: true,
          photoUrl: true,
        },
        orderBy: {
          points: 'desc',
        },
        skip,
        take,
      });

      const usersWithPositions = users.map((user, index) => ({
        ...user,
        position: skip + index + 1,
      }));

      let currentUserEntry: {
        position: number;
        accountId?: number;
        firstName?: string | null;
        lastName?: string | null;
        username?: string | null;
        photoUrl?: string | null;
        points?: number;
      } | null = null;
      if (currentUserId) {
        const currentUserRank = await this.getUserRank(currentUserId);
        if (currentUserRank) {
          currentUserEntry = {
            ...(await this.prisma.generalUser.findUnique({
              where: { accountId: currentUserId },
              select: {
                accountId: true,
                firstName: true,
                lastName: true,
                username: true,
                points: true,
                photoUrl: true,
              },
            })),
            position: currentUserRank,
          };
        }
      }

      const response = {
        data: usersWithPositions,
        meta: {
          currentPage: page,
          itemsPerPage: limit,
          totalItems: totalUsers,
          totalPages: Math.ceil(totalUsers / limit),
        },
        currentUser: currentUserEntry,
      };

      await this.cacheManager.set(cacheKey, response, 60000);

      return toJSON(response);
    } catch (error) {
      console.error('Error in getLeaderboard:', error);
      throw error;
    }
  }

  private async getUserRank(userId: number): Promise<number | null> {
    try {
      const result = await this.prisma.$queryRaw<Array<{ rank: number }>>`
        SELECT rank FROM (
          SELECT 
            "accountId", 
            RANK() OVER (ORDER BY points DESC) as rank
          FROM "GeneralUser"
        ) ranked_users
        WHERE "accountId" = ${userId}
      `;

      return result[0]?.rank || null;
    } catch (error) {
      console.error('Error getting user rank:', error);
      return null;
    }
  }

  private processCachedLeaderboard(cached: any, currentUserId?: number) {
    if (currentUserId && !cached.currentUser) {
      return this.getUserRank(currentUserId).then((rank) => {
        if (rank) {
          return this.prisma.generalUser
            .findUnique({
              where: { accountId: currentUserId },
              select: {
                accountId: true,
                firstName: true,
                lastName: true,
                username: true,
                points: true,
                photoUrl: true,
              },
            })
            .then((user) => ({
              ...cached,
              currentUser: user ? { ...user, position: rank } : null,
            }));
        }
        return cached;
      });
    }
    return cached;
  }

  async invalidateCache() {
    const keys = await (this.cacheManager as any).store.keys('leaderboard:*');
    await Promise.all(keys.map((key) => this.cacheManager.del(key)));
  }
}
