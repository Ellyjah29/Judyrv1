import { Module } from '@nestjs/common';
import { LeaderboardService } from './leaderboard.service';
import { LeaderboardController } from './leaderboard.controller';
import { CacheModule } from '@nestjs/cache-manager';
import { PrismaService } from '@app/core/database/prisma.service';

@Module({
  imports: [
    CacheModule.register({
      ttl: 60,
      max: 100,
    }),
  ],
  controllers: [LeaderboardController],
  providers: [LeaderboardService, PrismaService],
})
export class LeaderboardModule {}
