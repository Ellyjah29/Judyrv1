export const LEVELS = [
  { level: 1, name: 'Newbster', threshold: 0 },
  { level: 2, name: 'Blockchainer', threshold: 5000 },
  { level: 3, name: 'Hodler', threshold: 15000 },
  { level: 4, name: 'Moonwalker', threshold: 35000 },
  { level: 5, name: 'Whale Whisperer', threshold: 70000 },
  { level: 6, name: 'DeFi Sensei', threshold: 120000 },
  { level: 7, name: 'Crypto Overlord', threshold: 180000 },
];
