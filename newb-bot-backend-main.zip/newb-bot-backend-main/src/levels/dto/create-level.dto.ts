export class CreateLevelDto {}
