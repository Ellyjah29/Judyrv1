import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import TelegramBot = require('node-telegram-bot-api');
import { AuthService } from '../auth/auth.service';
import { TelegramVerificationService } from '../auth/telegram-verification.service';
import { PrismaService } from '@app/core/database/prisma.service';
import { CreateQuizDto } from './dto/create-quiz.dto';
import { Readable } from 'stream';
import { Cron, CronExpression } from '@nestjs/schedule';
import { Status } from '@prisma/client';

interface ActiveQuiz {
  pollId: string;
  correctOptionIndex: number;
  chatId: string | number;
  answeredUsers: Set<number>;
  messageId?: number;
}

interface ActivePoll {
  pollId: string;
  chatId: string | number;
  answeredUsers: Set<number>;
}

interface ScheduledQuiz {
  chatId: string | number;
  question: string;
  options: string[];
  correctOptionIndex: number;
  scheduledTime: Date;
}

interface CreatePollDto {
  chatId: string | number;
  question: string;
  options: string[];
}

interface MessageResult {
  chatId: string;
  success: boolean;
  message: string;
  error?: string;
}

export interface BulkMessageResponse {
  totalSent: number;
  totalFailed: number;
  results: MessageResult[];
  duration: number;
  failedChats: Array<{
    chatId: string;
    reason: string;
  }>;
}

interface ImageResult {
  chatId: string;
  success: boolean;
  message: string;
  error?: string;
  data?: any;
}

export interface BulkImageResponse {
  totalSent: number;
  totalFailed: number;
  results: ImageResult[];
  duration: number;
  failedChats: Array<{
    chatId: string;
    reason: string;
  }>;
}

@Injectable()
export class TelegramService {
  private bot: TelegramBot;
  private readonly logger = new Logger(TelegramService.name);
  private activeQuizzes: ActiveQuiz[] = [];
  private activePolls: ActivePoll[] = [];
  private scheduledQuizzes: ScheduledQuiz[] = [];
  private scheduledQuizTimeouts: Map<string, NodeJS.Timeout> = new Map();

  constructor(
    private readonly prisma: PrismaService,
    private readonly authService: AuthService,
    private readonly telegramVerificationService: TelegramVerificationService,
  ) {
    this.bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, {
      polling: true,
    });
    this.setupBot();
  }

  private async sendWelcomeMessage(msg: TelegramBot.Message) {
    const chatId = msg.chat.id;
    const startParam = msg.text?.match(/\/start(?: (.+))?/)?.[1];

    const webAppUrl = new URL(process.env.WEBAPP_URL!);
    const communityUrl = new URL(process.env.COMMUNITY_URL!);
    const channelUrl = new URL(process.env.CANNEL_URL!);

    if (startParam) {
      webAppUrl.searchParams.set('tg_start_param', startParam);
    }

    const username = msg.from?.username ? `@${msg.from.username}` : 'there';

    await this.bot.sendMessage(
      chatId,
      `👋 Welcome to Newbnet - Your Web3 Power Up!\n\nHey ${username},\n\nYou just stepped into Newbnet, the ultimate spot for learning, earning, and vibing with the crypto community.\n\nNo gatekeeping, no boring lectures - just fun, rewards, and alpha all in one place!\n\n✨ What we have:\n\n🟢 Newbot is your Telegram crypto coach that rewards you for learning\n🎯 Quizzes, Versus battles, marketplace and a surprise for early members\n💡 Stick around for daily fun topics, debates, and airdrop-worthy engagement\n\n🚀 Get in, introduce yourself, and let's get this Web3 journey started!`,
      {
        reply_markup: {
          inline_keyboard: [
            [
              {
                text: '👋 Launch',
                web_app: { url: webAppUrl.toString() },
              },
            ],
            [
              {
                text: 'Join community',
                url: communityUrl.toString(),
              },
            ],
            [
              {
                text: 'Join channel',
                url: channelUrl.toString(),
              },
            ],
          ],
        },
      },
    );
  }

  private setupBot() {
    this.bot.onText(/\/start(?: (.+))?/, async (msg) => {
      await this.sendWelcomeMessage(msg);
    });

    this.bot.on('message', async (msg) => {
      if (msg.text && !msg.text.startsWith('/')) {
        await this.sendWelcomeMessage(msg);
      }
    });

    this.bot.on('web_app_data', async (webAppMsg) => {
      const chatId = webAppMsg.chat.id;
      try {
        const initData = webAppMsg.web_app_data?.data;

        if (!initData) {
          throw new Error('No authentication data received');
        }

        const authResult = await this.authService.telegramLogin(initData);

        this.bot.sendMessage(
          chatId,
          '✅ Authentication successful! You can now use the web app.',
          {
            reply_markup: {
              inline_keyboard: [
                [
                  {
                    text: 'Continue in App',
                    web_app: { url: process.env.WEBAPP_URL },
                  },
                ],
              ],
            },
          },
        );
      } catch (error) {
        console.error('Telegram auth error:', error);
        this.bot.sendMessage(
          chatId,
          '❌ Authentication failed. Please try again or contact support.',
          {
            reply_markup: {
              inline_keyboard: [
                [
                  {
                    text: 'Retry Authentication',
                    web_app: { url: process.env.WEBAPP_URL },
                  },
                ],
              ],
            },
          },
        );
      }
    });

    this.bot.on('poll_answer', async (pollAnswer) => {
      const user = pollAnswer.user;

      const quiz = this.activeQuizzes.find(
        (q) => q.pollId === pollAnswer.poll_id,
      );

      if (quiz) {
        if (pollAnswer.option_ids[0] === quiz.correctOptionIndex) {
          if (quiz.answeredUsers.has(user.id)) {
            this.logger.log(
              `User ${user.first_name} (@${user.username}) with ID ${user.id} already answered quiz ${quiz.pollId} correctly.`,
            );
            return;
          }

          this.logger.log(
            `User ${user.first_name} (@${user.username}) with ID ${user.id} answered the quiz in chat ${quiz.chatId} correctly!`,
          );
          console.log('Correct answer from user:', {
            id: user.id,
            username: user.username,
            first_name: user.first_name,
            last_name: user.last_name,
            quiz,
          });

          quiz.answeredUsers.add(user.id);

          try {
            await this.prisma.quizWinners.create({
              data: {
                telegramId: user.id.toString(),
                username: user.username,
                firstName: user.first_name,
                lastName: user.last_name,
                chatId: quiz.chatId.toString(),
                pollId: quiz.pollId,
              },
            });
            this.logger.log(
              `Successfully logged quiz winner ${user.id} to the database.`,
            );
          } catch (error) {
            this.logger.error(
              `Failed to log quiz winner ${user.id} to the database:`,
              error,
            );
          }
        }
        return;
      }

      const poll = this.activePolls.find(
        (p) => p.pollId === pollAnswer.poll_id,
      );

      if (poll) {
        if (poll.answeredUsers.has(user.id)) {
          this.logger.log(
            `User ${user.first_name} (@${user.username}) with ID ${user.id} already voted in poll ${poll.pollId}.`,
          );
          return;
        }

        this.logger.log(
          `User ${user.first_name} (@${user.username}) with ID ${user.id} voted in poll ${poll.pollId} in chat ${poll.chatId}. Option: ${pollAnswer.option_ids[0]}`,
        );
        console.log('Poll vote from user:', {
          id: user.id,
          username: user.username,
          first_name: user.first_name,
          last_name: user.last_name,
          pollId: poll.pollId,
          chatId: poll.chatId,
          optionId: pollAnswer.option_ids[0],
        });

        poll.answeredUsers.add(user.id);

        try {
          await this.prisma.pollVotes.create({
            data: {
              telegramId: user.id.toString(),
              username: user.username,
              firstName: user.first_name,
              lastName: user.last_name,
              chatId: poll.chatId.toString(),
              pollId: poll.pollId,
              optionId: pollAnswer.option_ids[0],
            },
          });
          this.logger.log(
            `Successfully logged poll vote for user ${user.id} to the database.`,
          );
        } catch (error) {
          this.logger.error(
            `Failed to log poll vote for user ${user.id} to the database:`,
            error,
          );
        }
      }
    });

    this.bot.on('my_chat_member', async (chatMemberUpdate) => {
      const chat = chatMemberUpdate.chat;
      const newStatus = chatMemberUpdate.new_chat_member.status;
      const oldStatus = chatMemberUpdate.old_chat_member.status;

      if (newStatus === 'member' || newStatus === 'administrator') {
        this.logger.log(
          `Bot was added to ${chat.type} with ID ${chat.id}, title: ${chat.title || 'N/A'}`,
        );
        console.log('Bot added to chat:', {
          chatId: chat.id,
          chatType: chat.type,
          chatTitle: chat.title,
          chatUsername: chat.username,
        });

        try {
          await this.prisma.chat.upsert({
            where: { chatId: chat.id.toString() },
            update: {
              chatType: chat.type,
              title: chat.title,
              username: chat.username,
            },
            create: {
              chatId: chat.id.toString(),
              chatType: chat.type,
              title: chat.title,
              username: chat.username,
            },
          });
          this.logger.log(`Chat ${chat.id} saved/updated in database.`);
        } catch (error) {
          this.logger.error(
            `Failed to save chat ${chat.id} to database:`,
            error,
          );
        }

        try {
          await this.bot.sendMessage(
            chat.id,
            `🎉 Welcome to the future! Thanks for adding me to ${chat.title || 'this chat'}!\n\nI'm Newbot, your friendly Web3 coach here to make learning crypto fun with:\n✨ Interactive quizzes that reward you\n🗳️ Engaging community polls\n📚 Easy-to-digest crypto education\n🎯 Exciting community challenges\n\n📋 **Pro Tip**: For the best experience, consider making me an admin so I can share polls, quizzes, and educational content seamlessly. No worries - I only need basic permissions to serve you better!\n\nReady to dive into Web3 together? 🌊`,
          );
        } catch (error) {
          this.logger.error(
            `Failed to send welcome message to chat ${chat.id}:`,
            error,
          );
        }
      } else if (newStatus === 'kicked' || newStatus === 'left') {
        this.logger.log(
          `Bot was removed from ${chat.type} with ID ${chat.id}, title: ${chat.title || 'N/A'}`,
        );
        console.log('Bot removed from chat:', {
          chatId: chat.id,
          chatType: chat.type,
          chatTitle: chat.title,
          chatUsername: chat.username,
        });

        try {
          await this.prisma.chat.update({
            where: { chatId: chat.id.toString() },
            data: {
              status: Status.DELETED,
            },
          });
          this.logger.log(`Chat ${chat.id} status updated in database.`);
        } catch (error) {
          this.logger.error(`Failed to update chat ${chat.id} status:`, error);
        }
      }
    });
  }

  // Enhanced service method for bulk messaging
  public async sendBulkFormattedMessage(
    chatIds: string[],
    message: string,
    button?: {
      text: string;
      url: string;
      isWebApp?: boolean;
    },
  ): Promise<BulkMessageResponse> {
    const startTime = Date.now();
    const results: MessageResult[] = [];
    const failedChats: Array<{ chatId: string; reason: string }> = [];

    // Telegram rate limits: 30 messages per second to different chats
    const BATCH_SIZE = 10; // Process in smaller batches
    const DELAY_BETWEEN_BATCHES = 350; // 350ms delay between batches (roughly 28-29 messages per second)

    this.logger.log(`Starting bulk message send to ${chatIds.length} chats`);

    try {
      // Split chatIds into batches
      const batches: string[][] = [];
      for (let i = 0; i < chatIds.length; i += BATCH_SIZE) {
        batches.push(chatIds.slice(i, i + BATCH_SIZE));
      }

      for (let batchIndex = 0; batchIndex < batches.length; batchIndex++) {
        const batch = batches[batchIndex];
        this.logger.log(
          `Processing batch ${batchIndex + 1}/${batches.length} with ${batch.length} chats`,
        );

        // Process current batch concurrently
        const batchPromises = batch.map(async (chatId) => {
          try {
            await this.sendFormattedMessage(chatId, message, button);
            return {
              chatId,
              success: true,
              message: 'Message sent successfully',
            };
          } catch (error: any) {
            const errorReason = this.extractErrorReason(error);
            this.logger.error(
              `Failed to send message to ${chatId}: ${errorReason}`,
            );

            // Track failed chats with user-friendly reasons
            failedChats.push({
              chatId,
              reason: errorReason,
            });

            return {
              chatId,
              success: false,
              message: 'Failed to send message',
              error: errorReason,
            };
          }
        });

        const batchResults = await Promise.all(batchPromises);
        results.push(...batchResults);

        // Add delay between batches to respect rate limits (except for the last batch)
        if (batchIndex < batches.length - 1) {
          await this.delay(DELAY_BETWEEN_BATCHES);
        }
      }

      const duration = Date.now() - startTime;
      const totalSent = results.filter((r) => r.success).length;
      const totalFailed = results.filter((r) => !r.success).length;

      this.logger.log(
        `Bulk message completed: ${totalSent} sent, ${totalFailed} failed in ${duration}ms`,
      );

      return {
        totalSent,
        totalFailed,
        results,
        duration,
        failedChats,
      };
    } catch (error: any) {
      this.logger.error('Bulk message send failed:', error);
      throw new HttpException(
        'Bulk message send failed',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  // // Helper method to extract meaningful error reasons (add this if not exists)
  // private extractErrorReason(error: any): string {
  //   if (error.response && error.response.body) {
  //     const body = error.response.body;
  //     const errorCode = body.error_code;
  //     const description = body.description;

  //     // Map common error codes to user-friendly messages
  //     switch (errorCode) {
  //       case 403:
  //         if (description?.includes('kicked')) {
  //           return 'Bot was removed/kicked from the group';
  //         }
  //         if (description?.includes('blocked')) {
  //           return 'Bot was blocked by the chat';
  //         }
  //         return 'Bot lacks permission or was blocked/removed from chat';
  //       case 400:
  //         if (description?.includes('chat not found')) {
  //           return 'Chat not found or invalid chat ID';
  //         }
  //         if (description?.includes('not enough rights')) {
  //           return 'Bot lacks permission to send messages in this chat';
  //         }
  //         return `Bad request: ${description}`;
  //       case 429:
  //         return 'Rate limited - too many requests';
  //       case 404:
  //         return 'Chat not found';
  //       default:
  //         return `Telegram API Error (${errorCode}): ${description}`;
  //     }
  //   }

  //   if (error instanceof Error) {
  //     return error.message;
  //   }

  //   return 'Unknown error occurred';
  // }

  // Helper method for delays
  private delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  public async sendFormattedMessage(
    chatId: string | number,
    message: string,
    button?: {
      text: string;
      url: string;
      isWebApp?: boolean;
    },
  ) {
    try {
      const options: TelegramBot.SendMessageOptions = {
        parse_mode: 'Markdown',
        disable_web_page_preview: false,
      };

      const isGroupChat =
        typeof chatId === 'number'
          ? chatId < 0
          : chatId.toString().startsWith('-');

      if (button) {
        if (button.isWebApp && !isGroupChat) {
          options.reply_markup = {
            inline_keyboard: [
              [
                {
                  text: button.text,
                  web_app: { url: button.url },
                },
              ],
            ],
          };
        } else if (button.isWebApp && isGroupChat) {
          this.logger.warn(
            `Attempted to send WebApp button to group chat ${chatId}. Sending as a regular URL button instead. Functionality might differ.`,
          );
          options.reply_markup = {
            inline_keyboard: [
              [
                {
                  text: button.text,
                  url: button.url,
                },
              ],
            ],
          };
        } else {
          options.reply_markup = {
            inline_keyboard: [
              [
                {
                  text: button.text,
                  url: button.url,
                },
              ],
            ],
          };
        }
      }

      await this.bot.sendMessage(chatId, message, options);
      return { success: true, message: 'Message sent successfully' };
    } catch (error: any) {
      let errorMessage = 'Failed to send message';
      let statusCode = HttpStatus.INTERNAL_SERVER_ERROR;

      if (error.response && error.response.body) {
        const body = error.response.body;
        errorMessage = `Telegram API Error: ${body.error_code} - ${body.description}`;
        statusCode =
          body.error_code === 403
            ? HttpStatus.FORBIDDEN
            : HttpStatus.BAD_REQUEST;
        this.logger.error(
          `Failed to send message to ${chatId}: ${errorMessage}`,
        );
        if (body.error_code === 403) {
          this.logger.warn(
            `Bot was blocked by user ${chatId} or chat was deactivated.`,
          );
        }
      } else {
        this.logger.error(
          `Failed to send message to ${chatId}: ${error.message || error}`,
          error.stack,
        );
        if (error instanceof Error) {
          errorMessage = error.message;
        }
      }
      throw new HttpException(errorMessage, statusCode);
    }
  }

  public async sendAutoDeleteFormattedMessage(
    chatId: string | number,
    message: string,
    button?: {
      text: string;
      url: string;
      isWebApp?: boolean;
    },
  ) {
    try {
      const options: TelegramBot.SendMessageOptions = {
        parse_mode: 'Markdown',
        disable_web_page_preview: false,
      };

      const isGroupChat =
        typeof chatId === 'number'
          ? chatId < 0
          : chatId.toString().startsWith('-');

      if (button) {
        if (button.isWebApp && !isGroupChat) {
          options.reply_markup = {
            inline_keyboard: [
              [
                {
                  text: button.text,
                  web_app: { url: button.url },
                },
              ],
            ],
          };
        } else if (button.isWebApp && isGroupChat) {
          this.logger.warn(
            `Attempted to send WebApp button to group chat ${chatId}. Sending as a regular URL button instead. Functionality might differ.`,
          );
          options.reply_markup = {
            inline_keyboard: [
              [
                {
                  text: button.text,
                  url: button.url,
                },
              ],
            ],
          };
        } else {
          options.reply_markup = {
            inline_keyboard: [
              [
                {
                  text: button.text,
                  url: button.url,
                },
              ],
            ],
          };
        }
      }

      const sentMessage = await this.bot.sendMessage(chatId, message, options);
      this.logger.log(
        `Message sent to chat ${chatId}, will be deleted after 1 hour`,
      );

      // Schedule message deletion after 1 hour
      setTimeout(async () => {
        try {
          await this.bot.deleteMessage(chatId, sentMessage.message_id);
          this.logger.log(
            `Message ${sentMessage.message_id} deleted from chat ${chatId}`,
          );
        } catch (error) {
          this.logger.error(
            `Failed to delete message ${sentMessage.message_id} from chat ${chatId}:`,
            error,
          );
        }
      }, 3600 * 1000); // 1 hour

      return {
        success: true,
        message: 'Message sent successfully and will be deleted after 1 hour',
      };
    } catch (error: any) {
      let errorMessage = 'Failed to send auto-delete message';
      let statusCode = HttpStatus.INTERNAL_SERVER_ERROR;

      if (error.response && error.response.body) {
        const body = error.response.body;
        errorMessage = `Telegram API Error: ${body.error_code} - ${body.description}`;
        statusCode =
          body.error_code === 403
            ? HttpStatus.FORBIDDEN
            : HttpStatus.BAD_REQUEST;
        this.logger.error(
          `Failed to send auto-delete message to ${chatId}: ${errorMessage}`,
        );
        if (body.error_code === 403) {
          this.logger.warn(
            `Bot was blocked by user ${chatId} or chat was deactivated.`,
          );
        }
      } else {
        this.logger.error(
          `Failed to send auto-delete message to ${chatId}: ${error.message || error}`,
          error.stack,
        );
        if (error instanceof Error) {
          errorMessage = error.message;
        }
      }
      throw new HttpException(errorMessage, statusCode);
    }
  }

  private async generateLeaderboardMessage(
    chatId: string | number,
    period: 'Daily' | 'Weekly',
    startDate: Date,
    endDate: Date,
  ): Promise<string> {
    try {
      const leaderboard = await this.prisma.quizWinners.groupBy({
        by: ['telegramId', 'firstName'],
        where: {
          chatId: chatId.toString(),
          createdAt: {
            gte: startDate,
            lte: endDate,
          },
          deletedAt: null,
        },
        _sum: {
          points: true,
        },
        orderBy: {
          _sum: {
            points: 'desc',
          },
        },
        take: 10,
      });

      if (leaderboard.length === 0) {
        return `🏆 ${period} Leaderboard 🏆\n\nNo participants yet for this ${period.toLowerCase()} period.\nGet started with our quizzes to claim your spot!`;
      }

      let message = `🏆 ${period} Leaderboard 🏆\n\nTop ${Math.min(leaderboard.length, 10)} Quiz Masters:\n\n`;
      leaderboard.forEach((entry, index) => {
        const rank = index + 1;
        const name = entry.firstName || 'Unknown';
        const points = entry._sum.points || 0;
        message += `${rank}. ${name} - ${points} points\n`;
      });
      message += `\nKeep answering quizzes to climb the ranks! 🚀`;

      return message;
    } catch (error) {
      this.logger.error(
        `Failed to generate ${period.toLowerCase()} leaderboard for chat ${chatId}:`,
        error,
      );
      return `🏆 ${period} Leaderboard 🏆\n\nError generating leaderboard. Please try again later.`;
    }
  }

  private async sendDailyLeaderboard(chatId: string | number) {
    const now = new Date();
    const startOfDay = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate(),
    );
    const endOfDay = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate(),
      23,
      59,
      59,
      999,
    );

    const message = await this.generateLeaderboardMessage(
      chatId,
      'Daily',
      startOfDay,
      endOfDay,
    );

    try {
      await this.bot.sendMessage(chatId, message);
      this.logger.log(`Daily leaderboard sent to chat ${chatId}`);
    } catch (error) {
      this.logger.error(
        `Failed to send daily leaderboard to chat ${chatId}:`,
        error,
      );
    }
  }

  @Cron('0 0 10 * * 0', { timeZone: 'Africa/Lagos' })
  private async sendWeeklyLeaderboard() {
    const now = new Date();
    const startOfWeek = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() - now.getDay(),
    );
    const endOfWeek = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() - now.getDay() + 6,
      23,
      59,
      59,
      999,
    );

    const chatIds = await this.prisma.quizWinners.findMany({
      select: { chatId: true },
      distinct: ['chatId'],
      where: { deletedAt: null },
    });

    for (const { chatId } of chatIds) {
      if (!chatId) continue;
      const message = await this.generateLeaderboardMessage(
        chatId,
        'Weekly',
        startOfWeek,
        endOfWeek,
      );
      try {
        await this.bot.sendMessage(chatId, message);
        this.logger.log(`Weekly leaderboard sent to chat ${chatId}`);
      } catch (error) {
        this.logger.error(
          `Failed to send weekly leaderboard to chat ${chatId}:`,
          error,
        );
      }
    }
  }

  public async sendQuiz(createQuizDto: CreateQuizDto): Promise<any> {
    const { chatId, question, options, correctOptionIndex } = createQuizDto;

    if (
      !Array.isArray(options) ||
      options.some((opt) => typeof opt !== 'string')
    ) {
      this.logger.error(`Invalid options format: ${JSON.stringify(options)}`);
      throw new HttpException(
        'Options must be an array of strings.',
        HttpStatus.BAD_REQUEST,
      );
    }

    if (options.length < 2 || options.length > 10) {
      this.logger.error(`Invalid number of options: ${options.length}`);
      throw new HttpException(
        'Options must contain 2-10 items.',
        HttpStatus.BAD_REQUEST,
      );
    }

    if (correctOptionIndex < 0 || correctOptionIndex >= options.length) {
      this.logger.error(`Invalid correctOptionIndex: ${correctOptionIndex}`);
      throw new HttpException(
        'Correct option index is out of range.',
        HttpStatus.BAD_REQUEST,
      );
    }

    try {
      const sentMessage = await this.bot.sendPoll(chatId, question, options, {
        type: 'quiz',
        correct_option_id: correctOptionIndex,
        is_anonymous: false,
      });

      this.activeQuizzes.push({
        pollId: sentMessage.poll.id,
        correctOptionIndex: correctOptionIndex,
        chatId: chatId,
        answeredUsers: new Set<number>(),
      });

      setTimeout(() => {
        this.activeQuizzes = this.activeQuizzes.filter(
          (q) => q.pollId !== sentMessage.poll.id,
        );
      }, 3600 * 1000);

      return {
        success: true,
        message: 'Quiz sent successfully.',
        data: sentMessage,
      };
    } catch (error) {
      this.logger.error(`Failed to send quiz to chat ${chatId}:`, error);
      throw new HttpException(
        'Failed to send quiz.',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  public async sendAutoDeleteQuiz(createQuizDto: CreateQuizDto): Promise<any> {
    const { chatId, question, options, correctOptionIndex } = createQuizDto;

    if (
      !Array.isArray(options) ||
      options.some((opt) => typeof opt !== 'string')
    ) {
      this.logger.error(
        `Invalid options formatretrofit format: ${JSON.stringify(options)}`,
      );
      throw new HttpException(
        'Options must be an array of strings.',
        HttpStatus.BAD_REQUEST,
      );
    }

    if (options.length < 2 || options.length > 10) {
      this.logger.error(`Invalid number of options: ${options.length}`);
      throw new HttpException(
        'Options must contain 2-10 items.',
        HttpStatus.BAD_REQUEST,
      );
    }

    if (correctOptionIndex < 0 || correctOptionIndex >= options.length) {
      this.logger.error(`Invalid correctOptionIndex: ${correctOptionIndex}`);
      throw new HttpException(
        'Correct option index is out of range.',
        HttpStatus.BAD_REQUEST,
      );
    }

    try {
      const sentMessage = await this.bot.sendPoll(chatId, question, options, {
        type: 'quiz',
        correct_option_id: correctOptionIndex,
        is_anonymous: false,
      });

      this.activeQuizzes.push({
        pollId: sentMessage.poll.id,
        correctOptionIndex: correctOptionIndex,
        chatId: chatId,
        answeredUsers: new Set<number>(),
        messageId: sentMessage.message_id,
      });

      // Schedule reminder after 5 minutes
      setTimeout(async () => {
        try {
          const reminderMessage = await this.bot.sendMessage(
            chatId,
            '⏰ Only 5 minutes left to answer the quiz and claim your points! Jump in now! 🎯',
          );
          this.logger.log(
            `Reminder sent for quiz ${sentMessage.poll.id} in chat ${chatId}`,
          );

          // Schedule reminder deletion after 5 minutes
          setTimeout(async () => {
            try {
              await this.bot.deleteMessage(chatId, reminderMessage.message_id);
              this.logger.log(
                `Reminder message ${reminderMessage.message_id} deleted from chat ${chatId}`,
              );
            } catch (error) {
              this.logger.error(
                `Failed to delete reminder message ${reminderMessage.message_id} from chat ${chatId}:`,
                error,
              );
            }
          }, 300 * 1000); // 5 minutes
        } catch (error) {
          this.logger.error(
            `Failed to send reminder for quiz ${sentMessage.poll.id} in chat ${chatId}:`,
            error,
          );
        }
      }, 300 * 1000); // 5 minutes

      // Schedule quiz deletion after 10 minutes
      setTimeout(async () => {
        try {
          await this.bot.deleteMessage(chatId, sentMessage.message_id);
          this.logger.log(
            `Quiz message ${sentMessage.message_id} deleted from chat ${chatId}`,
          );
          this.activeQuizzes = this.activeQuizzes.filter(
            (q) => q.pollId !== sentMessage.poll.id,
          );
        } catch (error) {
          this.logger.error(
            `Failed to delete quiz message ${sentMessage.message_id} from chat ${chatId}:`,
            error,
          );
        }
      }, 600 * 1000); // 10 minutes

      return {
        success: true,
        message: 'Quiz sent successfully and will be deleted after 10 minutes.',
        data: sentMessage,
      };
    } catch (error) {
      this.logger.error(
        `Failed to send auto-delete quiz to chat ${chatId}:`,
        error,
      );
      throw new HttpException(
        'Failed to send auto-delete quiz.',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  public async scheduleQuizzes(
    chatIds: (string | number)[],
    quizzes: CreateQuizDto[],
    startTime: Date,
    intervalMinutes: number,
  ): Promise<any> {
    // Validate inputs
    if (!chatIds || !Array.isArray(chatIds) || chatIds.length === 0) {
      this.logger.error('Chat IDs array is required and must not be empty');
      throw new HttpException(
        'Chat IDs array is required and must not be empty.',
        HttpStatus.BAD_REQUEST,
      );
    }

    if (chatIds.length > 20) {
      this.logger.error(`Too many chat IDs provided: ${chatIds.length}`);
      throw new HttpException(
        'Maximum 10 chat IDs can be provided.',
        HttpStatus.BAD_REQUEST,
      );
    }

    // Validate each chatId
    for (const chatId of chatIds) {
      if (
        !chatId ||
        (typeof chatId !== 'string' && typeof chatId !== 'number')
      ) {
        this.logger.error(`Invalid chat ID: ${chatId}`);
        throw new HttpException(
          'All chat IDs must be valid strings or numbers.',
          HttpStatus.BAD_REQUEST,
        );
      }
    }

    if (!quizzes || !Array.isArray(quizzes) || quizzes.length === 0) {
      this.logger.error('Quizzes array is empty or invalid');
      throw new HttpException(
        'Quizzes array is required and must not be empty.',
        HttpStatus.BAD_REQUEST,
      );
    }

    if (quizzes.length > 20) {
      this.logger.error(`Too many quizzes provided: ${quizzes.length}`);
      throw new HttpException(
        'Maximum 20 quizzes can be scheduled.',
        HttpStatus.BAD_REQUEST,
      );
    }

    if (!startTime || isNaN(startTime.getTime())) {
      this.logger.error('Invalid start time provided');
      throw new HttpException(
        'Valid start time is required.',
        HttpStatus.BAD_REQUEST,
      );
    }

    const now = new Date();
    if (startTime < now) {
      this.logger.error('Start time is in the past');
      throw new HttpException(
        'Start time must be in the future.',
        HttpStatus.BAD_REQUEST,
      );
    }

    if (
      !intervalMinutes ||
      typeof intervalMinutes !== 'number' ||
      intervalMinutes < 1 ||
      intervalMinutes > 1440
    ) {
      this.logger.error(`Invalid interval minutes: ${intervalMinutes}`);
      throw new HttpException(
        'Interval minutes must be a number between 1 and 1440 (24 hours).',
        HttpStatus.BAD_REQUEST,
      );
    }

    // Validate each quiz
    for (const quiz of quizzes) {
      if (
        !Array.isArray(quiz.options) ||
        quiz.options.some((opt) => typeof opt !== 'string')
      ) {
        this.logger.error(
          `Invalid options format: ${JSON.stringify(quiz.options)}`,
        );
        throw new HttpException(
          'Options must be an array of strings.',
          HttpStatus.BAD_REQUEST,
        );
      }

      if (quiz.options.length < 2 || quiz.options.length > 10) {
        this.logger.error(`Invalid number of options: ${quiz.options.length}`);
        throw new HttpException(
          'Options must contain 2-10 items.',
          HttpStatus.BAD_REQUEST,
        );
      }

      if (
        quiz.correctOptionIndex < 0 ||
        quiz.correctOptionIndex >= quiz.options.length
      ) {
        this.logger.error(
          `Invalid correctOptionIndex: ${quiz.correctOptionIndex}`,
        );
        throw new HttpException(
          'Correct option index is out of range.',
          HttpStatus.BAD_REQUEST,
        );
      }
    }

    // Clear existing scheduled quizzes for all provided chatIds
    chatIds.forEach((chatId) => {
      this.scheduledQuizTimeouts.forEach((timeout, key) => {
        if (key.startsWith(`${chatId}-`)) {
          clearTimeout(timeout);
          this.scheduledQuizTimeouts.delete(key);
        }
      });
      this.scheduledQuizzes = this.scheduledQuizzes.filter(
        (q) => q.chatId !== chatId,
      );
    });

    // Calculate interval in milliseconds
    const intervalMs = intervalMinutes * 60 * 1000;

    // Schedule new quizzes for all chat IDs
    const allScheduledQuizzes: ScheduledQuiz[] = [];

    chatIds.forEach((chatId) => {
      quizzes.forEach((quiz, quizIndex) => {
        const scheduledTime = new Date(
          startTime.getTime() + quizIndex * intervalMs,
        );
        allScheduledQuizzes.push({
          chatId,
          question: quiz.question,
          options: quiz.options,
          correctOptionIndex: quiz.correctOptionIndex,
          scheduledTime,
        });
      });
    });

    this.scheduledQuizzes.push(...allScheduledQuizzes);

    // Schedule sending, reminder, deletion, and daily leaderboard for each chat
    chatIds.forEach((chatId) => {
      quizzes.forEach((quiz, quizIndex) => {
        const scheduledTime = new Date(
          startTime.getTime() + quizIndex * intervalMs,
        );
        const delay = scheduledTime.getTime() - now.getTime();
        const timeoutKey = `${chatId}-${quizIndex}`;

        const timeout = setTimeout(async () => {
          try {
            const sentMessage = await this.bot.sendPoll(
              chatId,
              quiz.question,
              quiz.options,
              {
                type: 'quiz',
                correct_option_id: quiz.correctOptionIndex,
                is_anonymous: false,
              },
            );

            this.activeQuizzes.push({
              pollId: sentMessage.poll.id,
              correctOptionIndex: quiz.correctOptionIndex,
              chatId: chatId,
              answeredUsers: new Set<number>(),
              messageId: sentMessage.message_id,
            });

            this.logger.log(
              `Quiz ${quizIndex + 1} sent to chat ${chatId} at ${new Date().toISOString()}`,
            );

            // Schedule reminder after 5 minutes
            setTimeout(async () => {
              try {
                const reminderMessage = await this.bot.sendMessage(
                  chatId,
                  '⏰ Only 5 minutes left to answer the quiz and claim your points! Jump in now! 🎯',
                );
                this.logger.log(
                  `Reminder sent for quiz ${sentMessage.poll.id} in chat ${chatId}`,
                );

                // Schedule reminder deletion after 5 minutes
                setTimeout(async () => {
                  try {
                    await this.bot.deleteMessage(
                      chatId,
                      reminderMessage.message_id,
                    );
                    this.logger.log(
                      `Reminder message ${reminderMessage.message_id} deleted from chat ${chatId}`,
                    );
                  } catch (error) {
                    this.logger.error(
                      `Failed to delete reminder message ${reminderMessage.message_id} from chat ${chatId}:`,
                      error,
                    );
                  }
                }, 300 * 1000); // 5 minutes
              } catch (error) {
                this.logger.error(
                  `Failed to send reminder for quiz ${sentMessage.poll.id} in chat ${chatId}:`,
                  error,
                );
              }
            }, 300 * 1000); // 5 minutes

            // Schedule quiz deletion after 10 minutes
            setTimeout(async () => {
              try {
                await this.bot.deleteMessage(chatId, sentMessage.message_id);
                this.logger.log(
                  `Quiz message ${sentMessage.message_id} deleted from chat ${chatId}`,
                );
                this.activeQuizzes = this.activeQuizzes.filter(
                  (q) => q.pollId !== sentMessage.poll.id,
                );

                // Send daily leaderboard after the last quiz for this chat
                if (quizIndex === quizzes.length - 1) {
                  await this.sendDailyLeaderboard(chatId);
                  this.logger.log(
                    `Triggered daily leaderboard for chat ${chatId}`,
                  );
                }
              } catch (error) {
                this.logger.error(
                  `Failed to delete quiz message ${sentMessage.message_id} from chat ${chatId}:`,
                  error,
                );
              }
            }, 600 * 1000); // 10 minutes

            // Remove from scheduled quizzes
            this.scheduledQuizzes = this.scheduledQuizzes.filter(
              (q) =>
                !(
                  q.chatId === chatId &&
                  q.question === quiz.question &&
                  q.scheduledTime.getTime() === scheduledTime.getTime()
                ),
            );
            this.scheduledQuizTimeouts.delete(timeoutKey);
          } catch (error) {
            this.logger.error(
              `Failed to send scheduled quiz ${quizIndex + 1} to chat ${chatId}:`,
              error,
            );
          }
        }, delay);

        this.scheduledQuizTimeouts.set(timeoutKey, timeout);
      });
    });

    return {
      success: true,
      message: `Successfully scheduled ${quizzes.length} quizzes for ${chatIds.length} chat(s) starting at ${startTime.toISOString()} with ${intervalMinutes}-minute intervals.`,
      data: {
        chatIds: chatIds,
        intervalMinutes: intervalMinutes,
        totalQuizzes: quizzes.length * chatIds.length,
        schedule: chatIds.map((chatId) => ({
          chatId,
          quizzes: quizzes.map((quiz, index) => ({
            quizNumber: index + 1,
            scheduledTime: new Date(startTime.getTime() + index * intervalMs),
            question: quiz.question,
          })),
        })),
      },
    };
  }

  // Method to Send a Poll
  public async sendPoll(createPollDto: CreatePollDto): Promise<any> {
    const { chatId, question, options } = createPollDto;

    if (
      !Array.isArray(options) ||
      options.some((opt) => typeof opt !== 'string')
    ) {
      this.logger.error(`Invalid options format: ${JSON.stringify(options)}`);
      throw new HttpException(
        'Options must be an array of strings.',
        HttpStatus.BAD_REQUEST,
      );
    }

    if (options.length < 2 || options.length > 10) {
      this.logger.error(`Invalid number of options: ${options.length}`);
      throw new HttpException(
        'Options must contain 2-10 items.',
        HttpStatus.BAD_REQUEST,
      );
    }

    try {
      const sentMessage = await this.bot.sendPoll(chatId, question, options, {
        type: 'regular',
        is_anonymous: false,
      });

      this.activePolls.push({
        pollId: sentMessage.poll.id,
        chatId: chatId,
        answeredUsers: new Set<number>(),
      });

      setTimeout(() => {
        this.activePolls = this.activePolls.filter(
          (p) => p.pollId !== sentMessage.poll.id,
        );
      }, 3600 * 1000);

      this.logger.log(`Poll sent successfully to chat ${chatId}`);
      return {
        success: true,
        message: 'Poll sent successfully.',
        data: sentMessage,
      };
    } catch (error) {
      this.logger.error(`Failed to send pollCaptcha to chat ${chatId}:`, error);
      throw new HttpException(
        'Failed to send poll.',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  // Updated service method for bulk image sending
  public async sendBulkImage(
    chatIds: string[],
    imageBuffer: Buffer,
    caption?: string,
  ): Promise<BulkImageResponse> {
    const startTime = Date.now();
    const results: ImageResult[] = [];
    const failedChats: Array<{ chatId: string; reason: string }> = [];

    // Telegram rate limits: 30 messages per second to different chats
    const BATCH_SIZE = 8; // Smaller batch size for images as they're heavier
    const DELAY_BETWEEN_BATCHES = 400; // Slightly longer delay for images

    this.logger.log(`Starting bulk image send to ${chatIds.length} chats`);

    try {
      // Split chatIds into batches
      const batches: string[][] = [];
      for (let i = 0; i < chatIds.length; i += BATCH_SIZE) {
        batches.push(chatIds.slice(i, i + BATCH_SIZE));
      }

      for (let batchIndex = 0; batchIndex < batches.length; batchIndex++) {
        const batch = batches[batchIndex];
        this.logger.log(
          `Processing image batch ${batchIndex + 1}/${batches.length} with ${batch.length} chats`,
        );

        // Process current batch concurrently
        const batchPromises = batch.map(async (chatId) => {
          try {
            const result = await this.sendImage(chatId, imageBuffer, caption);
            return {
              chatId,
              success: true,
              message: 'Image sent successfully',
              data: result.data,
            };
          } catch (error: any) {
            const errorReason = this.extractErrorReason(error);
            this.logger.error(
              `Failed to send image to ${chatId}: ${errorReason}`,
            );

            failedChats.push({
              chatId,
              reason: errorReason,
            });

            return {
              chatId,
              success: false,
              message: 'Failed to send image',
              error: errorReason,
            };
          }
        });

        const batchResults = await Promise.all(batchPromises);
        results.push(...batchResults);

        // Add delay between batches to respect rate limits (except for the last batch)
        if (batchIndex < batches.length - 1) {
          await this.delay(DELAY_BETWEEN_BATCHES);
        }
      }

      const duration = Date.now() - startTime;
      const totalSent = results.filter((r) => r.success).length;
      const totalFailed = results.filter((r) => !r.success).length;

      this.logger.log(
        `Bulk image send completed: ${totalSent} sent, ${totalFailed} failed in ${duration}ms`,
      );

      return {
        totalSent,
        totalFailed,
        results,
        duration,
        failedChats,
      };
    } catch (error: any) {
      this.logger.error('Bulk image send failed:', error);
      throw new HttpException(
        'Bulk image send failed',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  // Helper method to extract meaningful error reasons
  private extractErrorReason(error: any): string {
    if (error.response && error.response.body) {
      const body = error.response.body;
      const errorCode = body.error_code;
      const description = body.description;

      // Map common error codes to user-friendly messages
      switch (errorCode) {
        case 403:
          return 'Bot was blocked by the chat or chat is deactivated';
        case 400:
          if (description?.includes('chat not found')) {
            return 'Chat not found or invalid chat ID';
          }
          if (description?.includes('not enough rights')) {
            return 'Bot lacks permission to send messages in this chat';
          }
          return `Bad request: ${description}`;
        case 429:
          return 'Rate limited - too many requests';
        case 404:
          return 'Chat not found';
        default:
          return `Telegram API Error (${errorCode}): ${description}`;
      }
    }

    if (error instanceof Error) {
      return error.message;
    }

    return 'Unknown error occurred';
  }

  // Send Image to Telegram channel or group
  public async sendImage(
    chatId: string | number,
    imageBuffer: Buffer,
    caption?: string,
  ): Promise<any> {
    try {
      const imageStream = new Readable();
      imageStream.push(imageBuffer);
      imageStream.push(null);

      const sentMessage = await this.bot.sendPhoto(chatId, imageStream, {
        caption: caption || undefined,
        parse_mode: 'Markdown',
      });

      this.logger.log(`Image sent successfully to chat ${chatId}`);
      return {
        success: true,
        message: 'Image sent successfully.',
        data: sentMessage,
      };
    } catch (error: any) {
      let errorMessage = 'Failed to send image';
      let statusCode = HttpStatus.INTERNAL_SERVER_ERROR;

      if (error.response && error.response.body) {
        const body = error.response.body;
        errorMessage = `Telegram API Error: ${body.error_code} - ${body.description}`;
        statusCode =
          body.error_code === 403
            ? HttpStatus.FORBIDDEN
            : HttpStatus.BAD_REQUEST;
        this.logger.error(`Failed to send image to ${chatId}: ${errorMessage}`);
        if (body.error_code === 403) {
          this.logger.warn(
            `Bot was blocked by chat ${chatId} or chat was deactivated.`,
          );
        }
      } else {
        this.logger.error(
          `Failed to send image to ${chatId}: ${error.message || error}`,
          error.stack,
        );
        if (error instanceof Error) {
          errorMessage = error.message;
        }
      }
      throw new HttpException(errorMessage, statusCode);
    }
  }

  public async verifyMiniAppUser(initData: string) {
    try {
      return await this.telegramVerificationService.extractTelegramUserData(
        initData,
      );
    } catch (error) {
      console.error('Verification failed:', error);
      return null;
    }
  }

  private async getAllUserChatIds(): Promise<string[]> {
    try {
      const generalUsers = await this.prisma.generalUser.findMany({
        where: {
          telegramId: {},
        },
        select: {
          telegramId: true,
        },
      });

      const chatIds = generalUsers
        .map((user) => user.telegramId)
        .filter((id) => id !== null)
        .map((id) => id!.toString())
        .filter((id) => id.trim() !== '');

      if (chatIds.length === 0) {
        this.logger.warn('No user telegram IDs found in the database.');
      }
      return chatIds;
    } catch (error) {
      this.logger.error(
        'Failed to fetch user telegram IDs from database:',
        error,
      );
      return [];
    }
  }

  async broadcastMessageToAllUsers(
    message: string,
  ): Promise<{ successful: number; failed: number }> {
    const chatIds = await this.getAllUserChatIds();
    if (!chatIds || chatIds.length === 0) {
      this.logger.warn('No user chat IDs found to broadcast message.');
      return { successful: 0, failed: 0 };
    }

    const webAppUrl = process.env.WEBAPP_URL;
    if (!webAppUrl) {
      this.logger.error(
        'WEBAPP_URL is not defined in environment variables. Cannot add Launch button.',
      );
    }

    const launchButton = webAppUrl
      ? {
          text: '👋 Launch',
          url: webAppUrl,
          isWebApp: true,
        }
      : undefined;

    this.logger.log(`Starting broadcast to ${chatIds.length} users.`);
    const results = {
      successful: 0,
      failed: 0,
    };

    for (const chatId of chatIds) {
      try {
        await this.sendFormattedMessage(chatId, message, launchButton);
        this.logger.log(
          `Broadcast message with Launch button sent to user ID ${chatId}`,
        );
        results.successful++;
      } catch (error) {
        this.logger.error(
          `Failed to send broadcast message to user ID ${chatId} during broadcast loop.`,
        );
        results.failed++;
      }
    }
    this.logger.log(
      `Broadcast finished. Successful: ${results.successful}, Failed: ${results.failed}`,
    );
    return results;
  }

  public async sendLeaderboard(chatId: string | number, leaderboard: string) {
    try {
      const options: TelegramBot.SendMessageOptions = {
        parse_mode: 'Markdown',
        disable_web_page_preview: true,
      };

      await this.bot.sendMessage(chatId, `🏆 ${leaderboard}`, options);

      this.logger.log(`Leaderboard sent to chat ${chatId}`);
      return {
        success: true,
        message: 'Leaderboard sent successfully',
      };
    } catch (error: any) {
      let errorMessage = 'Failed to send leaderboard';
      let statusCode = HttpStatus.INTERNAL_SERVER_ERROR;

      if (error.response && error.response.body) {
        const body = error.response.body;
        errorMessage = `Telegram API Error: ${body.error_code} - ${body.description}`;
        statusCode =
          body.error_code === 403
            ? HttpStatus.FORBIDDEN
            : HttpStatus.BAD_REQUEST;
        this.logger.error(
          `Failed to send leaderboard to ${chatId}: ${errorMessage}`,
        );
        if (body.error_code === 403) {
          this.logger.warn(
            `Bot was blocked by user ${chatId} or chat was deactivated.`,
          );
        }
      } else {
        this.logger.error(
          `Failed to send leaderboard to ${chatId}: ${error.message || error}`,
          error.stack,
        );
        if (error instanceof Error) {
          errorMessage = error.message;
        }
      }
      throw new HttpException(errorMessage, statusCode);
    }
  }
}
