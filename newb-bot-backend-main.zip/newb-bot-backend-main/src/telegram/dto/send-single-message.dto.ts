import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class SendSingleMessageDto {
  @ApiProperty({
    type: String,
    description: 'Telegram Community chat Id',
    example: '-1002414675242 and -1002478732490',
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  chatId: string;

  @ApiProperty({
    type: String,
    description: 'message',
    example:
      "🚀 Newbot is LIVE — and it's time to earn while you learn!\n\nYou can now:\n• Study crypto in simple, fun lessons\n• Complete daily tasks and quizzes\n• Invite your friends & climb the leaderboard\n• Earn points that matter in the Newbnet ecosystem\n\nThe earlier you start, the more you stack.\nSo, what are you waiting for?\n\nTap the bot now and let's grow together",
    // example:
    //   "🚨 BIG NEWS, NEWBNET FAM! 🎉\n\n We’ve been selected as this week’s community-nominated project on @netrahive on twitter 💜\n\n This is a huge win for us, and we couldn’t have done it without YOU! 🙌 Now it’s time to show up and show out!\n\n Here’s how YOU can participate and win 🎁:\n\n 1️⃣ Post or quote retweet about @newbnet\\_ (in English 🇬🇧)\n 2️⃣ Use hashtags: #Netrahive and #NetrahiveContest\n 3️⃣ Retweet the announcement tweet\n 4️⃣ Join their Telegram: t.me/netrahive\n\n 🏆 5 winners will receive 2 $USDC each (on Polygon)!\n ⏰ Winners announced at the end of the week!",
    //   "parse_mode": "MarkdownV2"
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  message: string;

  @ApiProperty({
    type: String,
    description: 'message',
    example: {
      text: '👋Launch',
      webAppUrl: 'https://t.me/NewbNetBot',
      isWebApp: true,
    },
    required: true,
  })
  @IsNotEmpty()
  @IsString()
  button?: {
    text: string;
    url: string;
    isWebApp?: boolean;
  };
}
