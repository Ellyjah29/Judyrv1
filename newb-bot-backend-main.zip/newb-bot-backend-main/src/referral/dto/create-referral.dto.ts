export class CreateReferralDto {}
